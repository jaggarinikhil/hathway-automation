"""
Hathway STB Renewal Automation System
======================================
Entry point for the complete automation workflow.
"""

import asyncio
import sys
from pathlib import Path
from config import Config
from agents.logger_agent import LoggerAgent
from agents.login_agent import LoginAgent
from agents.popup_handler_agent import PopupHandlerAgent
from agents.navigation_agent import NavigationAgent
from agents.renewal_agent import RenewalAgent
from playwright.async_api import async_playwright


async def run_automation(config: Config):
    logger = LoggerAgent(config.log_file)
    logger.info("🚀 Hathway STB Renewal Automation Started")
    logger.info(f"📦 Total boxes to process: {len(config.box_numbers)}")

    successful_boxes = []
    failed_boxes = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=config.headless,
            slow_mo=config.slow_mo,
            args=["--start-maximized", "--disable-blink-features=AutomationControlled"]
        )

        context = await browser.new_context(
            viewport={"width": 1366, "height": 768},
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            )
        )

        page = await context.new_page()

        try:
            # ── STEP 1: Login ─────────────────────────────────────────────
            login_agent = LoginAgent(page, config, logger)
            login_success = await login_agent.login()

            if not login_success:
                logger.error("❌ Login failed after all retries. Aborting.")
                await browser.close()
                return [], config.box_numbers, logger.get_summary()

            logger.success("✅ Login successful")

            # ── STEP 2: Handle post-login popups ─────────────────────────
            popup_handler = PopupHandlerAgent(page, config, logger)
            await popup_handler.handle_all_popups()

            # ── STEP 3: Navigate to Package Management ───────────────────
            nav_agent = NavigationAgent(page, config, logger)
            nav_success = await nav_agent.go_to_package_management()

            if not nav_success:
                logger.error("❌ Could not navigate to Package Management. Aborting.")
                await browser.close()
                return [], config.box_numbers, logger.get_summary()

            # ── STEP 4: Renewal Loop ──────────────────────────────────────
            renewal_agent = RenewalAgent(page, config, logger)

            for idx, box_number in enumerate(config.box_numbers, 1):
                logger.info(f"\n{'─'*60}")
                logger.info(f"📺 Processing box {idx}/{len(config.box_numbers)}: {box_number}")
                logger.info(f"{'─'*60}")

                success = await renewal_agent.renew_box(box_number)

                if success:
                    successful_boxes.append(box_number)
                    logger.success(f"✅ Box {box_number} renewed successfully")
                else:
                    failed_boxes.append(box_number)
                    logger.error(f"❌ Box {box_number} failed after retries")

                # Small delay between boxes
                await asyncio.sleep(config.delay_between_boxes)

        except Exception as e:
            logger.error(f"💥 Unexpected error in main workflow: {e}", exc_info=True)
        finally:
            await browser.close()
            logger.info("🔒 Browser closed")

    summary = logger.get_summary()
    _print_final_report(successful_boxes, failed_boxes, summary, logger)
    return successful_boxes, failed_boxes, summary


def _print_final_report(successful, failed, summary, logger):
    report = f"""
╔══════════════════════════════════════════════════════════╗
║           HATHWAY STB RENEWAL — EXECUTION REPORT         ║
╠══════════════════════════════════════════════════════════╣
║  Total Boxes    : {len(successful) + len(failed):<38} ║
║  Successful     : {len(successful):<38} ║
║  Failed         : {len(failed):<38} ║
╠══════════════════════════════════════════════════════════╣
║  ✅ SUCCESSFUL BOXES                                      ║
{"".join(f"║    → {b:<52} ║\n" for b in successful) or "║    (none)                                                ║\n"}╠══════════════════════════════════════════════════════════╣
║  ❌ FAILED BOXES                                          ║
{"".join(f"║    → {b:<52} ║\n" for b in failed) or "║    (none)                                                ║\n"}╚══════════════════════════════════════════════════════════╝
"""
    print(report)
    logger.info(report)


if __name__ == "__main__":
    config = Config.from_args_or_env()
    asyncio.run(run_automation(config))
