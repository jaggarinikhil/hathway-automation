"""
agents/renewal_agent.py — Core renewal workflow for each STB box.

Steps per box:
  A. Search box number
  B. Click "Main TV"
  C. Click "Add Plan"
  D. Click "Hathway Bouquet"
  E. Select "HW TL BRONZE KMM 30d"
  F. Click Add → Confirm
  G. Validate success
"""

import asyncio
from playwright.async_api import Page
from agents.navigation_agent import NavigationAgent
from agents.popup_handler_agent import PopupHandlerAgent
from utils.helpers import (
    wait_and_click, human_type, random_delay,
    safe_click, scroll_into_view_and_click
)


class RenewalAgent:

    def __init__(self, page: Page, config, logger):
        self.page = page
        self.config = config
        self.logger = logger
        self._nav = NavigationAgent(page, config, logger)
        self._popup = PopupHandlerAgent(page, config, logger)

    # ── Public entry point ────────────────────────────────────────────────

    async def renew_box(self, box_number: str) -> bool:
        """
        Run the full renewal workflow for one box.
        Retries up to renewal_max_retries times on failure.
        Returns True if renewed successfully.
        """
        for attempt in range(1, self.config.renewal_max_retries + 2):  # +2 so first run = attempt 1
            self.logger.info(
                f"[RENEWAL][{box_number}] Attempt {attempt}/"
                f"{self.config.renewal_max_retries + 1}"
            )
            try:
                success = await self._run_renewal_steps(box_number)
                if success:
                    self.logger.log_box_result(box_number, True)
                    return True
            except Exception as e:
                self.logger.error(
                    f"[RENEWAL][{box_number}] Exception on attempt {attempt}: {e}",
                    exc_info=True
                )

            if attempt <= self.config.renewal_max_retries:
                self.logger.warning(f"[RENEWAL][{box_number}] Retrying — going back to search...")
                await self._nav.go_back_to_search()
                await random_delay(2.0, 3.5)
            else:
                self.logger.log_box_result(box_number, False, "Exceeded retry limit")

        return False

    # ── Step orchestrator ─────────────────────────────────────────────────

    async def _run_renewal_steps(self, box_number: str) -> bool:
        """Execute all renewal steps in sequence. Returns True on success."""

        # Step A — Search
        if not await self._step_search(box_number):
            self.logger.error(f"[RENEWAL][{box_number}] STEP A (Search) failed")
            return False

        # Dismiss any popups that appeared after search
        await self._popup.dismiss_popups_if_present()

        # Step B — Select Main TV
        if not await self._step_select_main_tv(box_number):
            self.logger.error(f"[RENEWAL][{box_number}] STEP B (Main TV) failed")
            return False

        # Step C — Add Plan
        if not await self._step_add_plan(box_number):
            self.logger.error(f"[RENEWAL][{box_number}] STEP C (Add Plan) failed")
            return False

        # Step D — Hathway Bouquet
        if not await self._step_select_bouquet(box_number):
            self.logger.error(f"[RENEWAL][{box_number}] STEP D (Bouquet) failed")
            return False

        # Step E — Select plan
        if not await self._step_select_plan(box_number):
            self.logger.error(f"[RENEWAL][{box_number}] STEP E (Plan select) failed")
            return False

        # Step F — Add → Confirm
        if not await self._step_add_and_confirm(box_number):
            self.logger.error(f"[RENEWAL][{box_number}] STEP F (Add/Confirm) failed")
            return False

        # Step G — Validate
        success = await self._step_validate(box_number)
        self.logger.log_step(box_number, "G-VALIDATE", success)
        return success

    # ── Individual steps ──────────────────────────────────────────────────

    async def _step_search(self, box_number: str) -> bool:
        """Enter box number in search bar and submit."""
        self.logger.info(f"[RENEWAL][{box_number}] STEP A: Searching...")

        try:
            search_box = await self.page.wait_for_selector(
                self.config.sel_search_box,
                timeout=self.config.element_timeout
            )
            if not search_box:
                raise RuntimeError("Search box not found")

            # Clear and type
            await search_box.triple_click()
            await asyncio.sleep(0.2)
            await human_type(self.page, self.config.sel_search_box, box_number)
            await random_delay(0.5, 1.0)

            # Click Search button
            clicked = await wait_and_click(
                self.page, self.config.sel_search_button, self.config
            )
            if not clicked:
                # Try pressing Enter as fallback
                await self.page.keyboard.press("Enter")

            await self.page.wait_for_load_state("networkidle", timeout=self.config.page_load_timeout)
            await random_delay(1.0, 2.0)

            self.logger.log_step(box_number, "A-SEARCH", True)
            return True

        except Exception as e:
            self.logger.error(f"[RENEWAL][{box_number}] STEP A exception: {e}")
            self.logger.log_step(box_number, "A-SEARCH", False, str(e))
            return False

    async def _step_select_main_tv(self, box_number: str) -> bool:
        """Click on 'Main TV' in the results."""
        self.logger.info(f"[RENEWAL][{box_number}] STEP B: Selecting Main TV...")

        try:
            # Wait for results to appear
            await asyncio.sleep(1.0)

            clicked = await scroll_into_view_and_click(
                self.page, self.config.sel_main_tv_link, self.config
            )

            if not clicked:
                # Try broader text search
                clicked = await safe_click(
                    self.page, "text=Main TV", timeout=self.config.element_timeout
                )

            if not clicked:
                raise RuntimeError("'Main TV' link not found in results")

            await self.page.wait_for_load_state("networkidle", timeout=self.config.page_load_timeout)
            await random_delay(1.0, 1.8)

            self.logger.log_step(box_number, "B-MAIN-TV", True)
            return True

        except Exception as e:
            self.logger.error(f"[RENEWAL][{box_number}] STEP B exception: {e}")
            self.logger.log_step(box_number, "B-MAIN-TV", False, str(e))
            return False

    async def _step_add_plan(self, box_number: str) -> bool:
        """Click the 'Add Plan' button."""
        self.logger.info(f"[RENEWAL][{box_number}] STEP C: Clicking Add Plan...")

        try:
            clicked = await scroll_into_view_and_click(
                self.page, self.config.sel_add_plan_button, self.config
            )
            if not clicked:
                raise RuntimeError("'Add Plan' button not found")

            await self.page.wait_for_load_state("networkidle", timeout=self.config.page_load_timeout)
            await random_delay(1.0, 1.8)

            self.logger.log_step(box_number, "C-ADD-PLAN", True)
            return True

        except Exception as e:
            self.logger.error(f"[RENEWAL][{box_number}] STEP C exception: {e}")
            self.logger.log_step(box_number, "C-ADD-PLAN", False, str(e))
            return False

    async def _step_select_bouquet(self, box_number: str) -> bool:
        """Click 'Hathway Bouquet' from the bouquet list."""
        self.logger.info(f"[RENEWAL][{box_number}] STEP D: Selecting Hathway Bouquet...")

        try:
            clicked = await scroll_into_view_and_click(
                self.page, self.config.sel_hathway_bouquet, self.config
            )
            if not clicked:
                raise RuntimeError("'Hathway Bouquet' not found")

            await self.page.wait_for_load_state("networkidle", timeout=self.config.page_load_timeout)
            await random_delay(1.0, 1.8)

            self.logger.log_step(box_number, "D-BOUQUET", True)
            return True

        except Exception as e:
            self.logger.error(f"[RENEWAL][{box_number}] STEP D exception: {e}")
            self.logger.log_step(box_number, "D-BOUQUET", False, str(e))
            return False

    async def _step_select_plan(self, box_number: str) -> bool:
        """
        Find and select "HW TL BRONZE KMM 30d" from the plan list.
        Strategy:
          1. Look for a row/cell containing the exact plan name.
          2. Click the 'Select' button within that row.
        """
        self.logger.info(
            f"[RENEWAL][{box_number}] STEP E: Selecting plan '{self.config.target_plan_name}'..."
        )

        try:
            plan_name = self.config.target_plan_name

            # Strategy 1: find <tr> containing the plan name, then click Select inside it
            plan_row_sel = f"tr:has-text('{plan_name}')"
            plan_row = await self.page.wait_for_selector(
                plan_row_sel, timeout=self.config.element_timeout
            )

            if plan_row:
                await plan_row.scroll_into_view_if_needed()
                await asyncio.sleep(0.4)

                # Look for a select/choose button inside this row
                select_btn = await plan_row.query_selector(
                    "button, a, input[type='button'], input[type='submit']"
                )
                if select_btn:
                    await select_btn.click()
                    await asyncio.sleep(1.0)
                    self.logger.log_step(box_number, "E-PLAN-SELECT", True)
                    return True

            # Strategy 2: generic text search
            clicked = await safe_click(
                self.page,
                f"text={plan_name}",
                timeout=self.config.element_timeout
            )
            if clicked:
                await asyncio.sleep(1.0)
                self.logger.log_step(box_number, "E-PLAN-SELECT", True)
                return True

            raise RuntimeError(f"Plan '{plan_name}' not found in plan list")

        except Exception as e:
            self.logger.error(f"[RENEWAL][{box_number}] STEP E exception: {e}")
            self.logger.log_step(box_number, "E-PLAN-SELECT", False, str(e))
            return False

    async def _step_add_and_confirm(self, box_number: str) -> bool:
        """Click Add, then Confirm to finalise the renewal."""
        self.logger.info(f"[RENEWAL][{box_number}] STEP F: Add → Confirm...")

        try:
            # Click Add
            add_clicked = await scroll_into_view_and_click(
                self.page, self.config.sel_add_button, self.config
            )
            if not add_clicked:
                raise RuntimeError("'Add' button not found")

            await random_delay(1.0, 2.0)
            await self._popup.dismiss_popups_if_present()

            # Click Confirm
            confirm_clicked = await scroll_into_view_and_click(
                self.page, self.config.sel_confirm_button, self.config
            )
            if not confirm_clicked:
                # Sometimes Confirm is inside a modal
                confirm_clicked = await safe_click(
                    self.page,
                    "button:has-text('Confirm'), input[value='Confirm']",
                    timeout=self.config.element_timeout
                )

            if not confirm_clicked:
                raise RuntimeError("'Confirm' button not found")

            await self.page.wait_for_load_state("networkidle", timeout=self.config.page_load_timeout)
            await random_delay(1.5, 2.5)

            self.logger.log_step(box_number, "F-ADD-CONFIRM", True)
            return True

        except Exception as e:
            self.logger.error(f"[RENEWAL][{box_number}] STEP F exception: {e}")
            self.logger.log_step(box_number, "F-ADD-CONFIRM", False, str(e))
            return False

    async def _step_validate(self, box_number: str) -> bool:
        """Check for a success message / indicator on the page."""
        self.logger.info(f"[RENEWAL][{box_number}] STEP G: Validating renewal...")

        try:
            # Look for an explicit success element
            success_el = await self.page.wait_for_selector(
                self.config.sel_success_message,
                timeout=self.config.element_timeout
            )
            if success_el and await success_el.is_visible():
                msg_text = await success_el.inner_text()
                self.logger.info(
                    f"[RENEWAL][{box_number}] Success message: '{msg_text.strip()[:100]}'"
                )
                return True

        except Exception:
            pass  # No explicit success element — check via URL or page content

        # Fallback: look for success keywords in page text
        try:
            page_text = await self.page.inner_text("body")
            keywords = ["success", "renewed", "activated", "added successfully", "plan added"]
            if any(kw in page_text.lower() for kw in keywords):
                self.logger.info(f"[RENEWAL][{box_number}] Success keyword found in page text")
                return True
        except Exception:
            pass

        # Fallback: absence of error
        try:
            error_sels = [
                ".alert-danger", ".error", ".error-message",
                "span.red", "span.error"
            ]
            for sel in error_sels:
                el = await self.page.query_selector(sel)
                if el and await el.is_visible():
                    err_text = await el.inner_text()
                    self.logger.warning(
                        f"[RENEWAL][{box_number}] Error indicator found: '{err_text.strip()[:100]}'"
                    )
                    return False
        except Exception:
            pass

        # If no error found, assume success (portal may not show explicit confirmation)
        self.logger.warning(
            f"[RENEWAL][{box_number}] No explicit success/error — assuming success"
        )
        return True
