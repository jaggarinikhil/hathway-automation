"""
utils/helpers.py — Shared utility functions used across all agents.

Functions:
• human_type()               — type text with random character delays
• random_delay()             — await a randomised sleep
• wait_and_click()           — wait for element, scroll, click
• safe_click()               — click without raising on failure
• scroll_into_view_and_click() — scroll element into view then click
• retry_async()              — generic async retry decorator/helper
"""

import asyncio
import random
from typing import Optional
from playwright.async_api import Page


# ── Typing ────────────────────────────────────────────────────────────────

async def human_type(page: Page, selector: str, text: str, clear: bool = True):
    """
    Type text into an input field with randomised delays between keystrokes
    to mimic human typing behaviour.
    """
    el = await page.wait_for_selector(selector, timeout=15_000)
    if el:
        if clear:
            await el.triple_click()
            await asyncio.sleep(0.15)
            await page.keyboard.press("Control+a")
            await page.keyboard.press("Delete")
            await asyncio.sleep(0.1)

        for char in text:
            await el.type(char, delay=random.uniform(50, 160))
            await asyncio.sleep(random.uniform(0.02, 0.08))


# ── Delays ────────────────────────────────────────────────────────────────

async def random_delay(min_s: float = 0.5, max_s: float = 1.5):
    """Sleep for a random duration between min_s and max_s seconds."""
    await asyncio.sleep(random.uniform(min_s, max_s))


# ── Click helpers ─────────────────────────────────────────────────────────

async def wait_and_click(
    page: Page,
    selector: str,
    config,
    timeout: Optional[int] = None
) -> bool:
    """
    Wait for a selector to be visible, scroll it into view, then click.
    Returns True on success, False on failure (no exception raised).
    """
    _timeout = timeout or config.element_timeout
    try:
        el = await page.wait_for_selector(selector, timeout=_timeout, state="visible")
        if not el:
            return False
        await el.scroll_into_view_if_needed()
        await asyncio.sleep(0.2)
        await el.click()
        await asyncio.sleep(config.delay_after_click)
        return True
    except Exception:
        return False


async def safe_click(page: Page, selector: str, timeout: int = 10_000) -> bool:
    """
    Attempt to click a selector. Returns True/False without raising.
    """
    try:
        el = await page.wait_for_selector(selector, timeout=timeout, state="visible")
        if el:
            await el.scroll_into_view_if_needed()
            await asyncio.sleep(0.2)
            await el.click()
            return True
    except Exception:
        pass
    return False


async def scroll_into_view_and_click(page: Page, selector: str, config) -> bool:
    """
    Finds the first matching element, scrolls it into view, then clicks.
    Falls back to JavaScript click if Playwright click fails.
    """
    try:
        el = await page.wait_for_selector(
            selector, timeout=config.element_timeout, state="attached"
        )
        if not el:
            return False

        await el.scroll_into_view_if_needed()
        await asyncio.sleep(0.3)

        try:
            await el.click(timeout=5_000)
        except Exception:
            # JavaScript fallback
            await page.evaluate("el => el.click()", el)

        await asyncio.sleep(config.delay_after_click)
        return True

    except Exception:
        return False


# ── Retry helper ──────────────────────────────────────────────────────────

async def retry_async(coro_func, max_retries: int = 3, delay: float = 1.5, *args, **kwargs):
    """
    Call `coro_func(*args, **kwargs)` up to `max_retries` times.
    Returns the result on first success, or raises the last exception.
    """
    last_exc: Optional[Exception] = None
    for attempt in range(1, max_retries + 1):
        try:
            return await coro_func(*args, **kwargs)
        except Exception as e:
            last_exc = e
            if attempt < max_retries:
                await asyncio.sleep(delay * attempt)  # exponential back-off
    raise last_exc
