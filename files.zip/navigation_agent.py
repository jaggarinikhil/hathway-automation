"""
agents/navigation_agent.py — Navigates between sections of the portal.

Responsibilities:
• Click "Package Management" in the sidebar/menu.
• Wait until the page is fully loaded and stable.
• Expose helper for returning to a known state between box renewals.
"""

import asyncio
from playwright.async_api import Page
from utils.helpers import wait_and_click, random_delay


class NavigationAgent:

    def __init__(self, page: Page, config, logger):
        self.page = page
        self.config = config
        self.logger = logger

    # ── Public ────────────────────────────────────────────────────────────

    async def go_to_package_management(self) -> bool:
        """
        Navigate to the Package Management section.
        Returns True on success.
        """
        self.logger.info("[NAV] Navigating to Package Management...")

        for attempt in range(1, self.config.step_max_retries + 1):
            try:
                # If already on Package Management, skip click
                if await self._is_on_package_management():
                    self.logger.info("[NAV] Already on Package Management page")
                    return True

                clicked = await wait_and_click(
                    self.page,
                    self.config.sel_package_mgmt_menu,
                    self.config,
                    timeout=self.config.element_timeout
                )

                if not clicked:
                    raise RuntimeError("Package Management menu item not found/clickable")

                await self.page.wait_for_load_state(
                    "networkidle", timeout=self.config.page_load_timeout
                )
                await random_delay(1.0, 2.0)

                if await self._is_on_package_management():
                    self.logger.success("[NAV] Package Management page loaded")
                    return True

                self.logger.warning(f"[NAV] Attempt {attempt}: page did not confirm Package Mgmt")

            except Exception as e:
                self.logger.error(f"[NAV] Attempt {attempt} exception: {e}")

            await asyncio.sleep(2)

        self.logger.error("[NAV] Failed to reach Package Management after retries")
        return False

    async def go_back_to_search(self) -> bool:
        """
        After completing (or failing) a renewal, navigate back to the
        Package Management search page so the next box can be processed.
        """
        try:
            # Try a simple back navigation first
            await self.page.go_back(
                wait_until="networkidle",
                timeout=self.config.page_load_timeout
            )
            await random_delay(0.8, 1.5)

            # If that didn't work, click the menu again
            if not await self._is_on_package_management():
                return await self.go_to_package_management()

            return True
        except Exception as e:
            self.logger.warning(f"[NAV] go_back_to_search exception: {e} — re-navigating via menu")
            return await self.go_to_package_management()

    # ── Private ───────────────────────────────────────────────────────────

    async def _is_on_package_management(self) -> bool:
        """
        Heuristic check: look for the search bar that is present on
        the Package Management page.
        """
        try:
            el = await self.page.query_selector(self.config.sel_search_box)
            if el and await el.is_visible():
                return True
        except Exception:
            pass

        # Fallback: URL contains relevant keyword
        url = self.page.url.lower()
        return any(k in url for k in ["packagemgmt", "package_mgmt", "packagemanagement"])
